export { default as ProductsTable } from "./ProductsTable";
export { default as ClientsTable } from "./ClientsTable";
export { default as TrafficsTable } from "./TrafficsTable";
export { default as InvoiceTable } from "./InvoiceTable";
export { default as OrdersTable } from "./OrdersTable";
export { default as UsersTable } from "./UsersTable";
export { default as PagesTable } from "./PagesTable";
export { default as DealsTable } from "./DealsTable";
