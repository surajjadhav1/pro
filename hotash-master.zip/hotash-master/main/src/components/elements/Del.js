import React from "react";

export default function Del({ children, className }) {
    return <del className={ className }>{ children }</del>
}